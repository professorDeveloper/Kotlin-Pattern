package amaliyot6

class NormalFile : File {
    override fun read(name: String) = println("File O`qilmoqda: $name")
}