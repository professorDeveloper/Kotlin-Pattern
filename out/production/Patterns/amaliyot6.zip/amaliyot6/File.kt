package amaliyot6

interface File {
    fun read(name: String)
}
