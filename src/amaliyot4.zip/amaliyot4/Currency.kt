package amaliyot4

class Currency(
    val code: String
)
