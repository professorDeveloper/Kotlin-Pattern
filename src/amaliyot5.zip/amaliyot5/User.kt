package amaliyot5

data class User(val login: String)

