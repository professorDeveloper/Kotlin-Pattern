package amaliyot7
class Memory : Equipment(280, "Memory")
