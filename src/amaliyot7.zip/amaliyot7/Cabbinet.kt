package amaliyot7

class Cabbinet : Composite("cabbinet")
