import amaliyot7.Equipment

class FloppyDisk : Equipment(70, "Floppy Disk")
