package amaliyot7
class HardDrive : Equipment(250, "Hard Drive")
